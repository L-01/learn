#ifndef MAIN_M_H
#define MAIN_M_H

void main_m(void);

#endif//MAIN_M_H
