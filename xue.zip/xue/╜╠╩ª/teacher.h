#ifndef TEACHER_H
#define TEACHER_H

//#define MAX_stu 100
//#define MAX_stu2 100
//#define MAX_tch 100
//#define MAX_tch2 100
struct Teacher
{
	char name[20];
	char sex;
	int id;
	char pass[10];
	int n;
};
extern struct Teacher tch[100],tch2[100],t;

void init_t(void);
//密码判定
void passin_t(void);
//教师操作界面
char menu_t(void);
//添加学生
void add_one(void);
void add_more(void);
void add(void);
//删除学生
void del(void);
//寻找学生
void find_name(void);
int find_id(void);
void find(void);
//修改学生（按姓名、学号）
void modify_name(int i);
void modify_score(int i);
void modify(void);
//录入成绩
void std_inone(void);
void std_inmore(void);
void std_in(void);
//重置学生密码
void rebuilt(void);
//显示所有在校学生信息
void show_in(void);
//显示所有退出学生信息
void show_out(void);
//保存学生信息
void save_s(void);
#endif//TEACHER_H
