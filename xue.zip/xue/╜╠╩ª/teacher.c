#include"teacher.h"
#include"student.h"
#include"change.h"
#include"main_t.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<getch.h>
#include<unistd.h>
#define MAX_stu 100
#define MAX_stu2 100
#define MAX_tch 100
#define MAX_tch2 100
//extern tea tch[100],tch2[100],t;
struct Teacher tch[100],tch2[100],t,t1;
 
extern struct Student stu[1000],stu2[1000],s;
//struct Studen s;
int stu_num=0;//学生总人数

//static FILE *fp_s=NULL,*fp_t=NULL,*fp_s2=NULL;

void init_t(void)
{
	int id=0;
	FILE *fp_s=fopen("student.txt","r");
	if(fp_s==NULL)
	{
		puts("学生信息数据路径错误!");
		puts("---------------------");
		any();
		return;
	}
	while(fread(&s,sizeof(s),1,fp_s)!=0)
	{
		id=s.id%2019-1;
		stu[id]=s;
		stu_num++;
	}
	fclose(fp_s);
	passin_t();
}
void passin_t(void)
{
	int i=0;
	char c,pass[10]="123456";
	FILE *fp_t=fopen("teacher.txt","r+");
	if(fp_t==NULL)
	{
		puts("数据路径错误!");
		puts("-------------------");
		any();
		return;
	}
		system("clear");
		puts("教师模式");
		puts("-------------------");
		printf("请输入工号:\n");	
		scanf("%d%c",&t.id,&c);
		printf("请输入密码:\n");
		scanf("%s%c",t.pass,&c);
		puts("-------------------");
		i=t.id%2019-1;
		t1.id=t.id-1;//确保t1.id!=t.id
		while(i-->=0 && t1.id!=t.id)
		{
			fread(&t1,sizeof(t),1,fp_t);
//			printf("%d",t1.n);
		}
		if(t1.sex==0 || t1.id!=t.id)
		{
			printf("无效工号!\n");
			puts("-------------------");
//			rewind(fp_t);//文件结构指针回到开头
			any();
			return;
		}
		fseek(fp_t,-1*sizeof(t),SEEK_CUR);//文件结构指针回退一个结构体长度，为后续做准备
		if(t1.n==3)
		{
	//		printf("%d111111111111",t1.n);
			printf("账户锁定,请联系校长!\n");
			puts("-------------------");
			any();
			return;
		}
		if(!strcmp(t.pass,t1.pass))
		{
			if(!strcmp(t1.pass,pass))
			{
				puts("首次登录请重置密码!");
				puts("---------------------");
				first(t1.pass);//初次登录改密码
			}
			t1.n=0;
			fwrite(&t1,sizeof(t),1,fp_t);
			fseek(fp_t,-1*sizeof(t),SEEK_CUR);
			main_t();
		}
		else
		{
			puts("密码错误!");
			puts("-------------------");
			any();
			t1.n++;
			fwrite(&t1,sizeof(t),1,fp_t);
			fseek(fp_t,-1*sizeof(t),SEEK_CUR);
		}

	
	fclose(fp_t);
	return;
}
char menu_t(void)
{
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("-----------------------");
	puts("1、添加学生");
	puts("2、删除学生");
	puts("3、查找学生");
	puts("4、修改学生信息");
	puts("5、录入学生成绩");
	puts("6、重置学生密码");
	puts("7、显示所有在校学生信息");
	puts("8、显示所有退出学生信息");
	puts("9、退出系统");
	puts("-----------------------");
	printf("请输入指令:");
	char cmd=getch();
	return cmd;
}
//排名
void rank(void)
{
	int sum=0;
	for(int i=0; i<MAX_stu; i++)
	{
		stu[i].rank=1;
		sum=stu[i].g_chinese+stu[i].g_math+stu[i].g_english;
		for(int j=0; j<MAX_stu; j++)
		{
			if(sum<stu[j].g_chinese+stu[j].g_math+stu[j].g_english)	stu[i].rank++;
		}
	}
}
void add_one(void)
{
	if(stu_num>=MAX_stu)
	{
		puts("学生已满!");
		puts("---------------");
		any();
		return;
	}
	int i=0;
	char c;
	while(stu[i].sex!=0)	i++;
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("---------------");
		printf("请输入学生姓名:\n");
		fgets(s.name,100,stdin);
//		scanf("%s%c",s.name,&c);
		puts("---------------");
		if(strlen(s.name)>=18)
		{
			puts("无效姓名!");
			puts("---------------");
			any();
			continue;
		}
		s.name[strlen(s.name)-1]='\0';
		printf("请输入学生性别:\n");
		scanf("%c%c",&s.sex,&c);
		puts("---------------");
		if(s.sex!='w'&&s.sex!='m')
		{
			puts("无效姓别!");
			puts("---------------");
			any();
			continue;
		}
		stu_num++;
		puts("添加成功!");
		puts("---------------");
		any();
		break;
	}
	stu[i]=s;
	stu[i].id=2019*10000+i+1;
//初始化学生密码
	strcpy(stu[i].code,"123456");
}
void add_more(void)
{
	int i=0,n=0;
	char c,file[100]={};
	FILE *fp=NULL;
	if(stu_num>=MAX_stu)
	{
		puts("学生已满!");
		any();
		return;
	}
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("--------------------------");
		printf("请输入待导入文件路径:\n");
		scanf("%s%c",file,&c);
		puts("--------------------------");
		fp=fopen(file,"r");
		if(NULL==fp)
		{
			puts("无效路径，请重输!");
			puts("--------------------------");
			any();
			continue;
		}
//		while(fscanf(fp,"%s",s.name)!=EOF&&fscanf(fp," %c",&s.sex)!=EOF)
		while(fscanf(fp,"\n%[^\n]",s.name)!=EOF&&fscanf(fp," %c",&s.sex)!=EOF)
		{
//			printf("%d  %c",i,s.sex);
//			s.name(strlen(s,name))='\0';
			while(stu[i].sex!=0)	i++;
			stu[i]=s;
			stu[i].id=2019*10000+i+1;
//初始化学生密码
			strcpy(stu[i].code,"123456");
			stu_num++;
			n++;
			if(stu_num>=MAX_stu)
			{
				printf("学生已满!仅导入%d名学生\n",n);
				puts("--------------------------");
				any();
				return;
			}
		}
		break;
	}
	puts("导入完毕");
	fclose(fp);
	puts("--------------------------");
	any();
	return;
}
void add(void)
{
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("------------");
		puts("1、单个添加");
		puts("2、批量导入");
		puts("3、退出");
		puts("------------");
		printf("请输入指令:");
		switch(getch())
		{
			case '1':add_one();break;
			case '2':add_more();break;
			case '3':return;
		}
		rank();//更新排名
	}
	
}
//删除学生
void del(void)
{
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("-------------------------");
	int i=0,id1=0,id2=0;
	char c;
	FILE *fp;
	while(1)
	{
		printf("请输入要删除学生学号:\n");
		scanf("%d%c",&id1,&c);
		printf("请再次输入要删除学生学号:\n");
		scanf("%d%c",&id2,&c);
		if(id1!=id2)
		{
			puts("-------------------------");
			puts("两次输入不相同，请重输!");
			puts("-------------------------");
			any();
		}
		else
		{
			break;
		}
	}
	i=id1%2019-1;
	if(stu[i].sex!=0)
	{
		fp=fopen("student2.txt","a");
		if(NULL==fp)
		{
			puts("-------------------------");
			puts("未发现离校学生档案!");
			puts("-------------------------");
			any();
			return;
		}
		fwrite(&stu[i],sizeof(s),1,fp);
		fclose(fp);
		stu[i].sex=0;
		stu_num--;
		puts("-------------------------");
		puts("已删除并转入离校学生档案。");
		puts("-------------------------");
		rank();//更新排名
		puts("-------------------------");
		any();
		return;
	}
	else
		puts("查无此人!");
	puts("-------------------------");
	any();
}
//寻找学生
void find_name(void)
{
	int n=0,i=0,j=0;
	char name[20],c;
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("------------");
	printf("请输入姓名:\n");
	scanf("%s%c",name,&c);
	while(i<MAX_stu)
	{		
		if(stu[i].sex!=0)
		{
			for( j=0; j<strlen(name); j++)
				if(name[j]!=stu[i].name[j])	break;
			if(j==strlen(name))
			{
				if(i==0)
				{
					system("clear");
					printf("教师模式|欢迎 %s !\n",t1.name);
					puts("-------------------------------------------------------");
					puts("姓名                 性别 学号      语文 数学 英语 排名");
					puts("-------------------------------------------------------");
				}
				printf("%s",stu[i].name);
				spacey(stu[i].name);
				printf(" %s   %d   %d   %d   %d   %d\n",stu[i].sex=='w'?"女":"男",stu[i].id,stu[i].g_chinese,stu[i].g_math,stu[i].g_english,stu[i].rank);
				n++;
			}
		}
		i++;
	}
	if(n==0)
	{
		puts("------------");
		puts("查无此人");
		puts("------------");
	}
	else	puts("-------------------------------------------------------");
	any();
}
int find_id(void)
{
	int id=0;
	char c;
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("------------");
	printf("请输入学号:\n");
	scanf("%d%c",&id,&c);
	id=id%2019-1;				
	if(stu[id].sex!=0)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("------------------------------------------------------");
		puts("姓名                 性别 学号      语文 数学 英语 排名");
		puts("------------------------------------------------------");
		printf("%s",stu[id].name);
		spacey(stu[id].name);
		printf(" %s   %d   %d   %d   %d   %d\n",stu[id].sex=='w'?"女":"男",stu[id].id,stu[id].g_chinese,stu[id].g_math,stu[id].g_english,stu[id].rank);
		puts("------------------------------------------------------");
	}
	else
	{
		puts("------------");
		puts("查无此人");
		puts("------------");
	}
	any();
	return id;
}
void find(void)
{
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("-------------");
		puts("1、按姓名查找");
		puts("2、按学号查找");
		puts("3、退出");
		puts("-------------");
		printf("请输入指令:");
		switch(getch())
		{
			case '1':find_name();break;
			case '2':find_id();break;
			case '3':return;
		}
	}
}
void modify_name(int i)
{
	char c;
	int id=0;
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("----------------------");
		printf("输入新姓名、学号、性别:\n");
		scanf("%s %d %c%c",s.name,&s.id,&s.sex,&c);
		puts("----------------------");
		id=s.id%2019-1;
		if(stu[id].sex!=0)
		{
			puts("该学号已有学生，请重输!");
			puts("----------------------");
			any();
		}
		else
		{
			stu[id]=s;
			stu[id].g_chinese=stu[i].g_chinese;
			stu[id].g_math=stu[i].g_math;
			stu[id].g_english=stu[i].g_english;
			stu[i].sex=0;
			puts("修改成功!");
			puts("----------------------");
			any();
			return;
		}
	}
}
void modify_score(int i)
{
	char c;
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("---------------------------");
		printf("输入新语文、数学、英语成绩:\n");
		scanf("%d %d %d%c",&s.g_chinese,&s.g_math,&s.g_english,&c);
		puts("---------------------------");
		if(s.g_chinese<0||s.g_math<0||s.g_english<0||s.g_chinese>100||s.g_math>100||s.g_english>100)
		{
			puts("无效成绩，请重输!");
			puts("---------------------------");
			any();
		}
		else
		{
			stu[i].g_chinese=s.g_chinese;
			stu[i].g_math=s.g_math;
			stu[i].g_english=s.g_english;
			puts("修改成功!");
			puts("---------------------------");
			rank();//更新排名
			any();
			return;
		}
	}
}
void modify(void)
{
	int i=0;
	while(1)
	{
		i=find_id();
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("------------------------------------------------------");
		puts("姓名                 性别 学号      语文 数学 英语 排名");
		puts("------------------------------------------------------");
		printf("%s",stu[i].name);
		spacey(stu[i].name);
		printf(" %s   %d   %d   %d   %d   %d\n",stu[i].sex=='w'?"女":"男",stu[i].id,stu[i].g_chinese,stu[i].g_math,stu[i].g_english,stu[i].rank);
		
		puts("------------------------------------------------------");
		puts("1、修改基础信息");
		puts("2、修改成绩信息");
		puts("3、退出");
		puts("------------------------------------------------------");
		printf("请输入指令:");
		switch(getch())
		{
			case '1':modify_name(i);break;
			case '2':modify_score(i);break;
			case '3':return;
		}
	}
}
void std_inone(void)
{
	int id=0;
	char c;
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("------------");
	printf("请输入学号:\n");
	scanf("%d%c",&id,&c);
	puts("------------");
	id=id%2019-1;				
	if(stu[id].sex!=0)
	{
		while(1)
		{
			system("clear");
			printf("教师模式|欢迎 %s !\n",t1.name);
			puts("-------------------------");
			printf("输入语文、数学、英语成绩:\n");
			scanf("%d %d %d%c",&s.g_chinese,&s.g_math,&s.g_english,&c);
			if(s.g_chinese<0||s.g_math<0||s.g_english<0||s.g_chinese>100||s.g_math>100||s.g_english>100)
			{
				puts("无效成绩，请重输!");
				puts("-------------------------");
				any();
			}
			else
			{
				stu[id].g_chinese=s.g_chinese;
				stu[id].g_math=s.g_math;
				stu[id].g_english=s.g_english;
				puts("录入成功!");
				puts("-------------------------");
				any();
				return;
			}
		}
		
	}
	else
		puts("查无此人");
	puts("------------");
	any();
	return;
}
void std_inmore(void)
{
	char c,file[100]={};
	int id=0;
	FILE *fp=NULL;
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("----------------------");
		printf("请输入待导入文件路径:\n");
		scanf("%s%c",file,&c);
		fp=fopen(file,"r");
		if(NULL==fp)
		{
			puts("无效路径，请重输!");
			any();
			continue;
		}
		while(fscanf(fp,"%d",&s.id)!=EOF&&fscanf(fp,"%d",&s.g_chinese)!=EOF&&fscanf(fp,"%d",&s.g_math)!=EOF&&fscanf(fp,"%d",&s.g_english)!=EOF)
		{
			id=s.id%2019-1;
			stu[id].id=s.id;
			stu[id].g_chinese=s.g_chinese;
			stu[id].g_math=s.g_math;
			stu[id].g_english=s.g_english;
		}
		break;
	}
	puts("导入完毕");
	puts("----------------------");
	any();
	return;
}
void std_in(void)
{
	while(1)
	{
		system("clear");
		printf("教师模式|欢迎 %s !\n",t1.name);
		puts("--------------");
		puts("1、单个录入成绩");
		puts("2、批量录入成绩");
		puts("3、退出");
		puts("---------------");
		printf("请输入指令:");
		switch(getch())
		{
			case '1':std_inone();break;
			case '2':std_inmore();break;
			case '3':return;
		}
		rank();//更新排名
	}
}
void rebuilt(void)
{
	int id=0;
	char c;
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("----------------------");
	printf("请输入学号:\n");
	scanf("%d%c",&id,&c);
	puts("----------------------");
	id=id%2019-1;				
	if(stu[id].sex!=0)
	{
		strcpy(stu[id].code,"123456");
		stu[id].count=0;
		puts("重置密码成功!");
		puts("----------------------");
		any();
		return;
	}
	else
		puts("查无此人");
	puts("----------------------");
	any();
	return;
}
void show_in(void)
{
	int i=0;
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("------------------------------------------------------");
	puts("姓名                 性别 学号      语文 数学 英语 排名");
	puts("------------------------------------------------------");
	for(; i<MAX_stu; i++)
	{
		if(stu[i].sex!=0)
		{
			printf("%s",stu[i].name);
			spacey(stu[i].name);
			printf(" %s   %d   %d   %d   %d   %d\n",stu[i].sex=='w'?"女":"男",stu[i].id,stu[i].g_chinese,stu[i].g_math,stu[i].g_english,stu[i].rank);
		}	
	}
	puts("------------------------------------------------------");
	any();
	return;
}
void show_out(void)
{
	int i=0;
	FILE *fp=fopen("student2.txt","r");
	if(NULL==fp)
	{
		puts("未发现离校学生档案!");
		any();
		return;
	}
	while(fread(&s,sizeof(s),1,fp)!=0)
	{
		stu2[i++]=s;
	}
	fclose(fp);
	system("clear");
	printf("教师模式|欢迎 %s !\n",t1.name);
	puts("------------------------------------");
	puts("姓名                 性别 离校前学号");
	puts("------------------------------------");
	for(i=0; i<MAX_stu2; i++)
	{
		if(stu2[i].sex!=0)
		{
			printf("%s",stu2[i].name);
			spacey(stu2[i].name);
			printf(" %s   %d\n",stu2[i].sex=='w'?"女":"男",stu2[i].id);
		}
	}
	puts("------------------------------------");
	any();
	return;
}
//保存学生信息
void save_s(void)
{
	FILE *fp=fopen("student.txt","w");
	int i=0;
	if(NULL==fp)
	{
		puts("未发现学生档案!");
		any();
		return;
	}
	for( i=0; i<MAX_stu; i++)
	{
		if(stu[i].sex!=0)
			fwrite(&stu[i],sizeof(s),1,fp);
	}
	fclose(fp);
/*	if(stu2[0].sex!=0)
	{
		fp=fopen("student2.txt","w");
		if(NULL==fp)
		{
			puts("未发现离校学生档案!");
			any();
			return;
		}
		for( i=0; i<MAX_stu; i++)
		{
			fwrite(&stu2[i],sizeof(s),1,fp);
		}
		fclose(fp);
	}*/
}
