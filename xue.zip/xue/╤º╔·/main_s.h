#ifndef MAIN_S_H
#define MAIN_S_H

void main_s(void);

#endif//MAIN_S_H
