#ifndef MAIN_T_H
#define MAIN_T_H

void main_t(void);

#endif//MAIN_T_H
